globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/-qLwiSqYG63zPKhtippjE/_buildManifest.js",
    "static/-qLwiSqYG63zPKhtippjE/_ssgManifest.js",
    "static/-qLwiSqYG63zPKhtippjE/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3vvarmgi6tyuq.js",
    "static/chunks/3_dqgnq3vl8kn.js",
    "static/chunks/3qbflt7cx6zcn.js",
    "static/chunks/turbopack-2u1d16houkiyo.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/page": {
      "otherChunks": [
        "static/chunks/3vvarmgi6tyuq.js",
        "static/chunks/3_dqgnq3vl8kn.js",
        "static/chunks/3qbflt7cx6zcn.js"
      ],
      "runtimeModuleIds": [
        40302
      ]
    },
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/3vvarmgi6tyuq.js",
        "static/chunks/3_dqgnq3vl8kn.js",
        "static/chunks/3qbflt7cx6zcn.js"
      ],
      "runtimeModuleIds": [
        40302
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/3vvarmgi6tyuq.js",
        "static/chunks/3_dqgnq3vl8kn.js",
        "static/chunks/3qbflt7cx6zcn.js"
      ],
      "runtimeModuleIds": [
        40302
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
