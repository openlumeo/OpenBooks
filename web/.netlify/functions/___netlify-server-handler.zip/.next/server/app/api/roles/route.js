var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/roles/route.js")
R.c("server/chunks/[root-of-the-server]__1uh6h2gqsmcnu._.js")
R.c("server/chunks/[root-of-the-server]__0cbc5xsb01qf5._.js")
R.c("server/chunks/_1wae3n2kpj_xw._.js")
R.c("server/chunks/_next-internal_server_app_api_roles_route_actions_173woi1iry1t_.js")
R.m(83694)
module.exports=R.m(83694).exports
