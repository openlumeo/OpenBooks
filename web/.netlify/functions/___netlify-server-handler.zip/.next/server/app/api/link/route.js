var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/link/route.js")
R.c("server/chunks/[root-of-the-server]__1uh6h2gqsmcnu._.js")
R.c("server/chunks/[root-of-the-server]__0cbc5xsb01qf5._.js")
R.c("server/chunks/_20hklxyygsd1w._.js")
R.c("server/chunks/_next-internal_server_app_api_link_route_actions_1o44pe0-bqt1x.js")
R.m(6697)
module.exports=R.m(6697).exports
