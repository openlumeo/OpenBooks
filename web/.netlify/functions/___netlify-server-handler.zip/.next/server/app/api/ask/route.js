var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/ask/route.js")
R.c("server/chunks/[root-of-the-server]__13oi_pql211e3._.js")
R.c("server/chunks/_0ybh7n66r3vd3._.js")
R.c("server/chunks/[root-of-the-server]__0cbc5xsb01qf5._.js")
R.c("server/chunks/_next-internal_server_app_api_ask_route_actions_04z4j2vj64fry.js")
R.m(87950)
module.exports=R.m(87950).exports
