var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/engine/[...path]/route.js")
R.c("server/chunks/[root-of-the-server]__021_xmntil42n._.js")
R.c("server/chunks/[root-of-the-server]__0cbc5xsb01qf5._.js")
R.c("server/chunks/_18v19-cfn7f6m._.js")
R.c("server/chunks/_next-internal_server_app_api_engine_[___path]_route_actions_0we24kpc-lg3r.js")
R.m(6374)
module.exports=R.m(6374).exports
