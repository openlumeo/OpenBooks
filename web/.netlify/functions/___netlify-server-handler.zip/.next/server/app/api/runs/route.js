var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/runs/route.js")
R.c("server/chunks/[root-of-the-server]__1uh6h2gqsmcnu._.js")
R.c("server/chunks/[root-of-the-server]__0cbc5xsb01qf5._.js")
R.c("server/chunks/_1l3f6n-7vtwn6._.js")
R.c("server/chunks/_next-internal_server_app_api_runs_route_actions_0kh91o2m-os97.js")
R.m(6047)
module.exports=R.m(6047).exports
