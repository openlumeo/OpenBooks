var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]__05v5l8q-3ywba._.js")
R.c("server/chunks/[root-of-the-server]__0cbc5xsb01qf5._.js")
R.c("server/chunks/_18vk8g05kjt5t._.js")
R.c("server/chunks/_next-internal_server_app_favicon_ico_route_actions_0g2jjlssn1kss.js")
R.m(56742)
module.exports=R.m(56742).exports
