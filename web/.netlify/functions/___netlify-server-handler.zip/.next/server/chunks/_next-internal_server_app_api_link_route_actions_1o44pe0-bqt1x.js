module.exports=[1562,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_link_route_actions_1o44pe0-bqt1x.js.map