module.exports=[24494,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_engine_%5B___path%5D_route_actions_0we24kpc-lg3r.js.map