module.exports=[28934,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_runs_route_actions_0kh91o2m-os97.js.map